/**
 * PRICING CONFIGURATION — NorthStar Medic
 * 
 * Implements the three pricing tiers from SOLO_FOUNDER_REVENUE_PLAN.js
 * - Guardian Pilot: $2,500 one-time + 30% commission
 * - Growth Lattice: $7,500 setup + 20% commission
 * - Network Core: Custom enterprise pricing
 * 
 * COMMISSION SPLITS:
 * - Direct Recovery: 30% for Guardian, 20% for Growth
 * - Biller Partnerships: 15% to biller, 15% to platform
 */

export const PRICING_TIERS = {
  GUARDIAN_PILOT: {
    id: 'guardian-pilot',
    name: 'Guardian Pilot',
    description: 'Perfect for small clinics (1-5 providers)',
    setupFee: 2500,           // One-time upfront
    commissionRate: 0.30,     // 30% of recovered amount
    billerCommissionRate: 0.15, // If brought by biller: they get 15%, platform keeps 15%
    minClaimValue: 5000,
    maxClaimValue: 15000,
    avgClaimValue: 8500,
    successRate: 0.40,        // 40% success rate
    stripePriceId: process.env.STRIPE_GUARDIAN_PRICE_ID,
    stripeProductId: process.env.STRIPE_GUARDIAN_PRODUCT_ID,
    features: [
      'OCR claim processing',
      'AI appeal drafting',
      'HIPAA BAA included',
      '30% commission on recoveries',
      'Email support',
      'Basic analytics'
    ]
  },

  GROWTH_LATTICE: {
    id: 'growth-lattice',
    name: 'Growth Lattice',
    description: 'For expanding billing teams and regional practices',
    setupFee: 7500,           // One-time upfront
    commissionRate: 0.20,     // 20% of recovered amount
    billerCommissionRate: 0.15, // If brought by biller: they get 15%, platform keeps 15%
    minClaimValue: 15000,
    maxClaimValue: 75000,
    avgClaimValue: 25000,
    successRate: 0.38,        // 38% success rate
    stripePriceId: process.env.STRIPE_GROWTH_PRICE_ID,
    stripeProductId: process.env.STRIPE_GROWTH_PRODUCT_ID,
    features: [
      'Everything in Guardian Pilot',
      'Advanced OCR with medical coding',
      'Multi-user dashboard',
      '20% commission on recoveries',
      'Priority support',
      'Advanced analytics & reporting',
      'API access',
      'Custom integrations'
    ]
  },

  NETWORK_CORE: {
    id: 'network-core',
    name: 'Network Core',
    description: 'Enterprise solution for hospitals and health systems',
    setupFee: null,           // Custom pricing
    commissionRate: null,     // Negotiated per contract
    billerCommissionRate: 0.15,
    minClaimValue: 25000,
    avgClaimValue: 45000,
    successRate: 0.35,        // 35% success rate
    stripePriceId: null,      // Custom pricing - no stripe price
    features: [
      'Everything in Growth Lattice',
      'White-label option',
      'Dedicated account manager',
      'Custom API integrations',
      'Negotiated commission rates',
      'SLA guarantees',
      'Whale-size claim volumes (5,000-50,000+ claims/month)'
    ]
  }
};

/**
 * Get pricing tier by ID
 */
export function getTier(tierId) {
  return PRICING_TIERS[tierId.toUpperCase().replace('-', '_')] || null;
}

/**
 * Calculate commission for a claim
 * @param {number} recoveredAmount - The amount recovered/appealed
 * @param {string} tierId - The pricing tier (guardian-pilot, growth-lattice, network-core)
 * @param {boolean} viaBiller - Whether this came through a biller partnership
 * @returns {Object} Commission breakdown
 */
export function calculateCommission(recoveredAmount, tierId, viaBiller = false) {
  const tier = getTier(tierId);
  if (!tier) throw new Error(`Invalid tier: ${tierId}`);

  let platformCommission = 0;
  let billerCommission = 0;

  if (viaBiller) {
    // Split: Biller gets 15%, Platform gets 15% of the amount
    billerCommission = recoveredAmount * tier.billerCommissionRate;
    platformCommission = recoveredAmount * tier.billerCommissionRate;
  } else {
    // Direct recovery: Platform takes full commission percentage
    platformCommission = recoveredAmount * tier.commissionRate;
    billerCommission = 0;
  }

  return {
    recoveredAmount,
    tier: tier.name,
    commissionRate: tier.commissionRate || 'Custom',
    platformCommission: Math.round(platformCommission * 100) / 100,
    billerCommission: Math.round(billerCommission * 100) / 100,
    totalCommission: Math.round((platformCommission + billerCommission) * 100) / 100,
    viaBiller
  };
}

/**
 * Calculate expected monthly revenue from a client
 * @param {number} claimsPerMonth - Number of claims processed per month
 * @param {string} tierId - The pricing tier
 * @param {number} avgClaimValue - Average claim value (uses tier default if not provided)
 * @param {number} successRate - Success rate (uses tier default if not provided)
 * @returns {Object} Revenue projection
 */
export function projectMonthlyRevenue(claimsPerMonth, tierId, avgClaimValue = null, successRate = null) {
  const tier = getTier(tierId);
  if (!tier) throw new Error(`Invalid tier: ${tierId}`);

  const actualAvgClaimValue = avgClaimValue || tier.avgClaimValue;
  const actualSuccessRate = successRate || tier.successRate;

  const successfulClaims = Math.floor(claimsPerMonth * actualSuccessRate);
  const totalRecovered = successfulClaims * actualAvgClaimValue;
  const platformCommission = totalRecovered * tier.commissionRate;

  return {
    tier: tier.name,
    claimsProcessed: claimsPerMonth,
    claimsSuccessful: successfulClaims,
    avgClaimValue: actualAvgClaimValue,
    successRate: actualSuccessRate,
    totalRecovered: Math.round(totalRecovered),
    platformCommission: Math.round(platformCommission),
    monthlyRecurringRevenue: Math.round(platformCommission)
  };
}

/**
 * WHALE HOSPITAL CALCULATION
 * 
 * Small clinic (3 docs): 40 claims/mo → $40,800/month
 * Regional hospital (200 beds): 2,000 claims/mo → $7,350,000/month
 * Health system (5,000+ beds): 8,000 claims/mo → $46,200,000/month
 */
export function whaleCalculation(clientType) {
  const scenarios = {
    family_practice: {
      name: 'Family Practice (3 docs)',
      claimsPerMonth: 40,
      tier: 'GUARDIAN_PILOT'
    },
    regional_hospital: {
      name: 'Regional Hospital (200 beds)',
      claimsPerMonth: 2000,
      tier: 'NETWORK_CORE',
      customRate: 0.30 // Negotiated
    },
    health_system: {
      name: 'Health System (5,000+ beds)',
      claimsPerMonth: 8000,
      tier: 'NETWORK_CORE',
      customRate: 0.30 // Negotiated
    }
  };

  const scenario = scenarios[clientType];
  if (!scenario) throw new Error(`Unknown client type: ${clientType}`);

  const tier = PRICING_TIERS[scenario.tier];
  const commissionRate = scenario.customRate || tier.commissionRate;
  const avgClaimValue = tier.avgClaimValue;

  const successfulClaims = Math.floor(scenario.claimsPerMonth * tier.successRate);
  const totalRecovered = successfulClaims * avgClaimValue;
  const monthlyCommission = totalRecovered * commissionRate;

  return {
    clientType: scenario.name,
    claimsPerMonth: scenario.claimsPerMonth,
    avgClaimValue,
    successRate: tier.successRate,
    claimsSuccessful: successfulClaims,
    totalRecovered,
    commissionRate: (commissionRate * 100).toFixed(1) + '%',
    monthlyRevenue: Math.round(monthlyCommission),
    annualRevenue: Math.round(monthlyCommission * 12)
  };
}

/**
 * YEAR 1 SCENARIO ANALYSIS
 * 
 * Shows revenue potential based on client mix and whale count
 */
export const YEAR_1_SCENARIOS = {
  foundation: {
    name: 'Foundation (Build credibility)',
    clinics: 14,
    billers: 8,
    whales: 0,
    healthSystems: 0,
    monthlyRevenue: 1000000,      // $1M/month
    yearlyRevenue: { min: 3000000, max: 8000000 },
    operatingCost: 1152 // $1,152/year
  },
  fifty_million: {
    name: '$50M/Month Target',
    clinics: 14,
    billers: 12,
    whales: 3,
    healthSystems: 0,
    monthlyRevenue: 50000000,      // $50M/month
    yearlyRevenue: { min: 300000000, max: 500000000 },
    operatingCost: 1152
  },
  two_hundred_million: {
    name: '$200M/Month Target',
    clinics: 20,
    billers: 20,
    whales: 5,
    healthSystems: 2,
    monthlyRevenue: 200000000,     // $200M/month
    yearlyRevenue: { min: 600000000, max: 1500000000 },
    operatingCost: 3000
  },
  five_hundred_million: {
    name: '$500M/Month Target',
    clinics: 30,
    billers: 30,
    whales: 10,
    healthSystems: 3,
    monthlyRevenue: 500000000,     // $500M/month
    yearlyRevenue: { min: 3000000000, max: 6000000000 },
    operatingCost: 3816
  }
};

/**
 * MONTHLY COSTS AT EACH SCALE
 */
export const OPERATING_COSTS = {
  current: {
    vercelHosting: 0,
    neonDatabase: 0,
    instantly: 0,
    porkbunEmail: 0,
    domain: 1,
    openaiApi: 5,
    stripeFees: 0,
    total: 6
  },
  atFirstRevenue: {
    vercelPro: 20,
    neonDatabase: 25,
    instantlyGrowth: 30,
    openaiApi: 20,
    total: 96
  },
  atScale: {
    vercelPro: 20,
    neonDatabase: 100,
    instantlyHypergrowth: 78,
    openaiApi: 100,
    additionalDomains: 20,
    total: 318
  }
};

export default {
  PRICING_TIERS,
  getTier,
  calculateCommission,
  projectMonthlyRevenue,
  whaleCalculation,
  YEAR_1_SCENARIOS,
  OPERATING_COSTS
};
