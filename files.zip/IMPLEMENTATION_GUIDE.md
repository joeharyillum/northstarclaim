# 🚀 PRICING IMPLEMENTATION GUIDE

## Overview

Your AI agent (revenue plan) has been broken down into **actual working code** that implements:

✅ Three pricing tiers (Guardian Pilot, Growth Lattice, Network Core)  
✅ Commission calculations (30%, 20%, custom rates)  
✅ Invoice generation based on claim recoveries  
✅ Stripe integration for checkout  
✅ Revenue projections and whale analysis  

---

## Files Created

### 1. **pricing-config.js** 
**Location:** `lib/pricing-config.js`

Defines all pricing tiers with:
- Setup fees ($2,500, $7,500, custom)
- Commission rates (30%, 20%, negotiated)
- Features for each tier
- Helper functions for calculations

**Key Functions:**
```javascript
getTier(tierId)
calculateCommission(amount, tierId, viaBiller)
projectMonthlyRevenue(claimsPerMonth, tierId)
whaleCalculation(clientType)
```

---

### 2. **invoice-service.js**
**Location:** `lib/invoice-service.js`

Handles the entire invoice workflow:
- Create invoices when claims are recovered
- Calculate commissions automatically
- Track earnings by user
- Dashboard stats

**Key Functions:**
```javascript
createInvoice(claim, tierId, recoveredAmount)
batchCreateInvoices(claims, tierId)
getUserInvoices(userId)
calculateUserEarnings(userId)
getDashboardStats(userId)
```

---

### 3. **stripe-integration.js**
**Location:** `lib/stripe-integration.js`

Connects Stripe for payments:
- Creates checkout sessions
- Handles successful payments
- Manages products and prices
- Tracks payment status

**Key Functions:**
```javascript
createCheckoutSession(tierId, userId, successUrl, cancelUrl)
handleSuccessfulPayment(sessionId)
getCheckoutStatus(sessionId)
createCheckoutLink(tierId)
```

---

### 4. **pricing-api-routes.js**
**Location:** `app/api/pricing/route.js` and `app/api/stripe/checkout/route.js`

Two API endpoints:

**GET/POST /api/pricing**
- List all tiers
- Get tier details
- Calculate commissions
- Project revenue
- Analyze whale scenarios

**POST /api/stripe/checkout**
- Create checkout session
- Verify payment
- Get session status

---

## Step-by-Step Integration

### Step 1: Copy Files to Your Project

```bash
# In your mediclaim-ai folder:
cp pricing-config.js lib/
cp invoice-service.js lib/
cp stripe-integration.js lib/
cp pricing-api-routes.js app/api/pricing/route.js
```

### Step 2: Update Environment Variables in Vercel

Already done! You have:
```
DATABASE_URL = ✅
DIRECT_URL = ✅
SENDGRID_API_KEY = ✅
STRIPE_SECRET_KEY = ✅ (already exists)
```

Add these for Stripe products (after running setup):
```
STRIPE_GUARDIAN_PRICE_ID = "price_xxx"
STRIPE_GUARDIAN_PRODUCT_ID = "prod_xxx"
STRIPE_GROWTH_PRICE_ID = "price_xxx"
STRIPE_GROWTH_PRODUCT_ID = "prod_xxx"
```

### Step 3: Initialize Stripe Products

Run once in your production environment:

```javascript
import { setupStripeProducts } from '@/lib/stripe-integration';

// Run this once
const setup = await setupStripeProducts();
console.log(setup);

// Copy the IDs into your Vercel env vars
```

### Step 4: Wire Up Your Claim Processing

When a claim is successfully appealed/recovered:

```javascript
import { createInvoice } from '@/lib/invoice-service';

// In your claim processing logic:
const recoveredAmount = 45000; // Example
const userTier = 'guardian-pilot'; // From user's payment record

const invoice = await createInvoice(
  claim,
  userTier,
  recoveredAmount,
  false // Set to true if via biller partnership
);

console.log(`Invoice created: ${invoice.invoiceId}`);
console.log(`Platform earned: $${invoice.platformCommission}`);
```

### Step 5: Update Dashboard to Show Earnings

```javascript
import { getDashboardStats } from '@/lib/invoice-service';

// In your dashboard page:
const stats = await getDashboardStats(userId);

// Display:
- Total Earned: $stats.totalEarned
- Pending Invoices: $stats.pendingAmount
- Next Payout: $stats.nextPayout
```

---

## How It Works: The Flow

### User Signup Flow

```
User clicks "Get Started" (Guardian Pilot)
  ↓
POST /api/stripe/checkout { tierId: 'guardian-pilot' }
  ↓
Stripe checkout session created
  ↓
User sees checkout page ($2,500)
  ↓
User pays successfully
  ↓
Stripe webhook: handleSuccessfulPayment()
  ↓
User's account updated with tier = 'guardian-pilot'
```

### Claim Processing Flow

```
Claim uploaded (billedAmount: $8,500)
  ↓
AI analyzes and appeals
  ↓
Insurance pays back: $5,100 (60% recovery)
  ↓
claim.status = 'RECOVERED'
  ↓
createInvoice(claim, 'guardian-pilot', 5100)
  ↓
Invoice created:
  - Platform earned: $1,530 (30% of $5,100)
  - Status: PENDING
  ↓
Stripe payment processed
  ↓
markInvoiceAsPaid()
  ↓
Payment shows in user's dashboard
```

### Revenue Projection for Sales

```
Hospital contact asks: "How much can we save?"

They have:
- 2,000 denied claims/month
- $45,000 avg claim value

Your response:
POST /api/pricing
{
  "action": "whale-analysis",
  "clientType": "regional_hospital"
}

Result:
{
  "clientType": "Regional Hospital (200 beds)",
  "claimsPerMonth": 2000,
  "claimsSuccessful": 700,
  "totalRecovered": "$31,500,000",
  "monthlyRevenue": "$7,350,000" ← Your commission
}
```

---

## Testing the Implementation

### Test 1: Get All Pricing Tiers

```bash
curl https://yourapp.com/api/pricing
```

Response:
```json
{
  "tiers": [
    {
      "id": "guardian-pilot",
      "name": "Guardian Pilot",
      "setupFee": 2500,
      "commissionRate": "30%",
      "features": [...]
    },
    ...
  ]
}
```

### Test 2: Calculate Commission

```bash
curl -X POST https://yourapp.com/api/pricing \
  -H "Content-Type: application/json" \
  -d '{
    "action": "calculate-commission",
    "tierId": "guardian-pilot",
    "recoveredAmount": 45000
  }'
```

Response:
```json
{
  "recoveredAmount": 45000,
  "tier": "Guardian Pilot",
  "commissionRate": 0.3,
  "platformCommission": 13500,
  "billerCommission": 0,
  "totalCommission": 13500
}
```

### Test 3: Project Revenue

```bash
curl -X POST https://yourapp.com/api/pricing \
  -H "Content-Type: application/json" \
  -d '{
    "action": "project-revenue",
    "tierId": "growth-lattice",
    "claimsPerMonth": 200
  }'
```

Response:
```json
{
  "tier": "Growth Lattice",
  "claimsProcessed": 200,
  "claimsSuccessful": 76,
  "totalRecovered": 1900000,
  "platformCommission": 380000,
  "monthlyRecurringRevenue": 380000
}
```

---

## Updating Pricing in the Future

If you need to change prices, commission rates, or tiers:

**Edit:** `lib/pricing-config.js`

```javascript
GUARDIAN_PILOT: {
  setupFee: 3000,  // Changed from 2500
  commissionRate: 0.35,  // Changed from 0.30
  ...
}
```

Then:
1. Redeploy to Vercel
2. Run `setupStripeProducts()` again to update Stripe
3. New customers get new pricing
4. Old customers keep their rate (stored in Payment records)

---

## Key Metrics Dashboard

Show these on your admin dashboard:

```javascript
import { getDashboardStats, calculateUserEarnings } from '@/lib/invoice-service';

const stats = await getDashboardStats(userId);
const yearToDate = await calculateUserEarnings(userId, startOfYear, today);

Dashboard:
- Total Earnings (All Time): ${stats.totalEarned}
- Year-to-Date: ${yearToDate.totalEarned}
- Pending Payment: ${stats.pendingAmount}
- Paid Invoices: ${stats.paidInvoices}
- Next Payout: ${stats.nextPayout}
```

---

## Webhook Integration (Important!)

When Stripe confirms a payment, you need to handle the webhook:

```javascript
// pages/api/webhooks/stripe.ts
import { handleSuccessfulPayment } from '@/lib/stripe-integration';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const event = req.body;

  if (event.type === 'checkout.session.completed') {
    await handleSuccessfulPayment(event.data.object.id);
    res.json({ received: true });
  } else {
    res.status(400).end();
  }
}
```

---

## Now Your Prices Are Connected! 🎉

- ✅ Pricing tiers defined
- ✅ Commission calculations automated
- ✅ Stripe checkout integrated
- ✅ Invoices generated automatically
- ✅ Revenue projections working
- ✅ Whale analysis ready

**Next Steps:**
1. Copy the files to your project
2. Test the API endpoints
3. Wire up claim processing to create invoices
4. Deploy to Vercel
5. Make your first sale! 🚀

---

## Support

If you have issues:

1. Check that all env vars are set in Vercel
2. Verify Stripe products were created: `setupStripeProducts()`
3. Look at error logs in Vercel dashboard
4. Check database migrations ran correctly

Good luck! 🌟
