/**
 * STRIPE INTEGRATION — NorthStar Medic
 * 
 * Handles:
 * - Creating/managing Stripe products for each pricing tier
 * - Generating checkout links with correct prices
 * - Handling successful payments
 * - Creating invoices when payments come in
 */

import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';
import { PRICING_TIERS } from './pricing-config.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const prisma = new PrismaClient();

/**
 * Setup Stripe products and prices for all tiers
 * Run this once during onboarding or when tiers change
 */
export async function setupStripeProducts() {
  const results = {};

  for (const [tierKey, tier] of Object.entries(PRICING_TIERS)) {
    if (!tier.setupFee) {
      console.log(`⏭️  Skipping ${tier.name} (custom pricing)`);
      continue;
    }

    try {
      // Create product
      const product = await stripe.products.create({
        name: tier.name,
        description: tier.description,
        metadata: {
          tier_id: tier.id,
          commission_rate: tier.commissionRate
        }
      });

      // Create price
      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: Math.round(tier.setupFee * 100), // Convert to cents
        currency: 'usd',
        type: 'one_time',
        metadata: {
          tier_id: tier.id
        }
      });

      results[tier.id] = {
        productId: product.id,
        priceId: price.id,
        name: tier.name,
        amount: tier.setupFee,
        commissionRate: tier.commissionRate
      };

      console.log(`✅ ${tier.name}: $${tier.setupFee} - Product: ${product.id}, Price: ${price.id}`);
    } catch (error) {
      console.error(`❌ Failed to create ${tier.name}:`, error);
      results[tier.id] = { error: error.message };
    }
  }

  return results;
}

/**
 * Create a checkout session for a specific tier
 * 
 * @param {string} tierId - guardian-pilot, growth-lattice, or network-core
 * @param {string} userId - The user creating the checkout
 * @param {string} successUrl - Where to redirect after payment
 * @param {string} cancelUrl - Where to redirect if payment is cancelled
 * @returns {Promise<Object>} Stripe checkout session
 */
export async function createCheckoutSession(tierId, userId, successUrl, cancelUrl) {
  const tier = PRICING_TIERS[tierId.toUpperCase().replace('-', '_')];
  
  if (!tier) {
    throw new Error(`Invalid tier: ${tierId}`);
  }

  if (!tier.stripePriceId) {
    throw new Error(`${tier.name} does not have a Stripe price configured. Contact support for custom pricing.`);
  }

  // Get user email
  const user = await prisma.user.findUnique({
    where: { id: userId }
  });

  if (!user) {
    throw new Error(`User not found: ${userId}`);
  }

  // Create checkout session
  const session = await stripe.checkout.sessions.create({
    customer_email: user.email,
    line_items: [
      {
        price: tier.stripePriceId,
        quantity: 1
      }
    ],
    mode: 'payment',
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: cancelUrl,
    metadata: {
      tier_id: tierId,
      user_id: userId,
      clinic_name: user.clinicName
    }
  });

  // Store the checkout session info
  await prisma.payment.create({
    data: {
      stripeSessionId: session.id,
      customerEmail: user.email,
      customerName: user.clinicName,
      tier: tierId,
      amount: Math.round(tier.setupFee * 100), // cents
      currency: 'usd',
      status: 'pending'
    }
  });

  return {
    sessionId: session.id,
    checkoutUrl: session.url,
    tier: tier.name,
    amount: tier.setupFee,
    customerEmail: user.email
  };
}

/**
 * Handle successful payment from Stripe webhook
 * Creates the user's account and initializes their pricing tier
 */
export async function handleSuccessfulPayment(sessionId) {
  // Retrieve session from Stripe
  const session = await stripe.checkout.sessions.retrieve(sessionId);

  if (session.payment_status !== 'paid') {
    throw new Error('Payment not completed');
  }

  const tierId = session.metadata.tier_id;
  const userId = session.metadata.user_id;

  // Update payment record
  await prisma.payment.update({
    where: { stripeSessionId: sessionId },
    data: {
      status: 'completed',
      stripeCustomerId: session.customer_details?.email
    }
  });

  // Update user's plan
  const user = await prisma.user.update({
    where: { id: userId },
    data: {
      // You'd store the current plan somewhere
      // For now, we're tracking it via the Payment record
      updatedAt: new Date()
    }
  });

  return {
    userId,
    tier: tierId,
    message: `Successfully onboarded to ${tierId}`,
    user
  };
}

/**
 * Get checkout status
 */
export async function getCheckoutStatus(sessionId) {
  const session = await stripe.checkout.sessions.retrieve(sessionId);
  
  return {
    sessionId: session.id,
    status: session.payment_status, // paid, unpaid, or no_payment_required
    customerEmail: session.customer_email,
    amount: session.amount_total ? session.amount_total / 100 : 0,
    currency: session.currency,
    tier: session.metadata?.tier_id,
    createdAt: new Date(session.created * 1000)
  };
}

/**
 * Create a checkout link (no session)
 * Returns a direct Stripe link for sharing
 */
export async function createCheckoutLink(tierId) {
  const tier = PRICING_TIERS[tierId.toUpperCase().replace('-', '_')];
  
  if (!tier) {
    throw new Error(`Invalid tier: ${tierId}`);
  }

  if (!tier.stripePriceId) {
    throw new Error(`${tier.name} requires custom pricing. Contact sales.`);
  }

  const link = await stripe.paymentLinks.create({
    line_items: [
      {
        price: tier.stripePriceId,
        quantity: 1
      }
    ],
    custom_text: {
      submit: {
        message: `Start your ${tier.name} plan for $${tier.setupFee}`
      }
    },
    metadata: {
      tier_id: tierId
    }
  });

  return {
    tier: tier.name,
    amount: tier.setupFee,
    url: link.url,
    description: tier.description,
    features: tier.features
  };
}

/**
 * Get all Stripe prices/products
 */
export async function getStripePricingSetup() {
  const products = await stripe.products.list();
  const prices = await stripe.prices.list();

  const setup = {
    products: products.data.map(p => ({
      id: p.id,
      name: p.name,
      tier: p.metadata?.tier_id
    })),
    prices: prices.data.map(p => ({
      id: p.id,
      productId: p.product,
      amount: p.unit_amount ? p.unit_amount / 100 : 'custom',
      currency: p.currency,
      tier: p.metadata?.tier_id
    }))
  };

  return setup;
}

/**
 * List all payments for admin/analytics
 */
export async function listPayments(limit = 50, offset = 0) {
  const payments = await prisma.payment.findMany({
    take: limit,
    skip: offset,
    orderBy: { createdAt: 'desc' }
  });

  const total = await prisma.payment.count();

  return {
    payments: payments.map(p => ({
      id: p.id,
      tier: p.tier,
      amount: p.amount / 100,
      status: p.status,
      customerEmail: p.customerEmail,
      createdAt: p.createdAt
    })),
    total,
    page: Math.floor(offset / limit) + 1,
    pageSize: limit
  };
}

/**
 * Calculate Stripe fees for transparency
 * Stripe charges ~2.9% + $0.30 per transaction
 */
export function calculateStripeFees(amount) {
  const percentFee = amount * 0.029;
  const fixedFee = 0.30;
  const totalFee = percentFee + fixedFee;
  const netAmount = amount - totalFee;

  return {
    grossAmount: amount,
    stripeFees: Math.round(totalFee * 100) / 100,
    netAmount: Math.round(netAmount * 100) / 100,
    feePercentage: (totalFee / amount * 100).toFixed(2) + '%'
  };
}

export default {
  setupStripeProducts,
  createCheckoutSession,
  handleSuccessfulPayment,
  getCheckoutStatus,
  createCheckoutLink,
  getStripePricingSetup,
  listPayments,
  calculateStripeFees
};
