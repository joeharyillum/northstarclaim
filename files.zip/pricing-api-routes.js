/**
 * API ROUTE: /api/pricing
 * 
 * Handles:
 * - GET /pricing - List all pricing tiers
 * - GET /pricing/:tierId - Get details of a specific tier
 * - POST /pricing/revenue-projection - Calculate projected MRR
 * - POST /pricing/whale-analysis - Analyze whale hospital scenarios
 */

import { NextResponse } from 'next/server';
import {
  PRICING_TIERS,
  getTier,
  calculateCommission,
  projectMonthlyRevenue,
  whaleCalculation,
  YEAR_1_SCENARIOS
} from '@/lib/pricing-config';

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const tierId = searchParams.get('tier');

  try {
    if (tierId) {
      // Get specific tier
      const tier = getTier(tierId);
      if (!tier) {
        return NextResponse.json(
          { error: `Tier not found: ${tierId}` },
          { status: 404 }
        );
      }
      return NextResponse.json({
        tier,
        estimatedMonthlyRevenue: projectMonthlyRevenue(50, tierId) // Example: 50 claims/mo
      });
    }

    // Return all tiers
    const tiers = Object.values(PRICING_TIERS).map(tier => ({
      id: tier.id,
      name: tier.name,
      setupFee: tier.setupFee,
      commissionRate: tier.commissionRate ? `${(tier.commissionRate * 100).toFixed(0)}%` : 'Custom',
      description: tier.description,
      minClaimValue: tier.minClaimValue,
      avgClaimValue: tier.avgClaimValue,
      features: tier.features
    }));

    return NextResponse.json({
      tiers,
      count: tiers.length
    });
  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { action, tierId, claimsPerMonth, recoveredAmount, clientType } = body;

    if (action === 'project-revenue') {
      // Calculate projected MRR for a specific tier
      if (!tierId || !claimsPerMonth) {
        return NextResponse.json(
          { error: 'Missing tierId or claimsPerMonth' },
          { status: 400 }
        );
      }

      const projection = projectMonthlyRevenue(claimsPerMonth, tierId);
      return NextResponse.json(projection);
    }

    if (action === 'calculate-commission') {
      // Calculate commission for a specific recovery
      if (!tierId || !recoveredAmount) {
        return NextResponse.json(
          { error: 'Missing tierId or recoveredAmount' },
          { status: 400 }
        );
      }

      const viaBiller = body.viaBiller || false;
      const commission = calculateCommission(recoveredAmount, tierId, viaBiller);
      return NextResponse.json(commission);
    }

    if (action === 'whale-analysis') {
      // Analyze whale scenarios
      if (!clientType) {
        return NextResponse.json(
          { error: 'Missing clientType' },
          { status: 400 }
        );
      }

      const analysis = whaleCalculation(clientType);
      return NextResponse.json(analysis);
    }

    if (action === 'year-1-scenarios') {
      // Return all Year 1 scenarios
      return NextResponse.json(YEAR_1_SCENARIOS);
    }

    return NextResponse.json(
      { error: 'Unknown action' },
      { status: 400 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

/**
 * STRIPE CHECKOUT API ROUTE: /api/stripe/checkout
 * 
 * POST /api/stripe/checkout
 * {
 *   "tierId": "guardian-pilot",
 *   "userId": "user-uuid",
 *   "successUrl": "https://yourapp.com/success",
 *   "cancelUrl": "https://yourapp.com/cancel"
 * }
 */

import { createCheckoutSession, handleSuccessfulPayment, getCheckoutStatus } from '@/lib/stripe-integration';
import { getSession } from 'next-auth/react';

export async function POST(req) {
  const session = await getSession({ req });

  if (!session) {
    return NextResponse.json(
      { error: 'Not authenticated' },
      { status: 401 }
    );
  }

  try {
    const body = await req.json();
    const { action, tierId, successUrl, cancelUrl, sessionId } = body;

    if (action === 'create') {
      // Create a new checkout session
      if (!tierId) {
        return NextResponse.json(
          { error: 'Missing tierId' },
          { status: 400 }
        );
      }

      const checkout = await createCheckoutSession(
        tierId,
        session.user.id,
        successUrl || `${process.env.NEXTAUTH_URL}/dashboard`,
        cancelUrl || `${process.env.NEXTAUTH_URL}/pricing`
      );

      return NextResponse.json(checkout);
    }

    if (action === 'status') {
      // Get checkout session status
      if (!sessionId) {
        return NextResponse.json(
          { error: 'Missing sessionId' },
          { status: 400 }
        );
      }

      const status = await getCheckoutStatus(sessionId);
      return NextResponse.json(status);
    }

    if (action === 'verify') {
      // Verify payment was successful
      if (!sessionId) {
        return NextResponse.json(
          { error: 'Missing sessionId' },
          { status: 400 }
        );
      }

      const result = await handleSuccessfulPayment(sessionId);
      return NextResponse.json({
        success: true,
        message: `Welcome to ${result.tier}!`,
        tier: result.tier
      });
    }

    return NextResponse.json(
      { error: 'Unknown action' },
      { status: 400 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

/**
 * USAGE EXAMPLES:
 * 
 * Get all pricing tiers:
 * GET /api/pricing
 * 
 * Get specific tier:
 * GET /api/pricing?tier=guardian-pilot
 * 
 * Project revenue for 100 claims/month in Growth Lattice:
 * POST /api/pricing
 * {
 *   "action": "project-revenue",
 *   "tierId": "growth-lattice",
 *   "claimsPerMonth": 100
 * }
 * 
 * Calculate commission on $45,000 recovery:
 * POST /api/pricing
 * {
 *   "action": "calculate-commission",
 *   "tierId": "guardian-pilot",
 *   "recoveredAmount": 45000
 * }
 * 
 * Analyze whale hospital scenario:
 * POST /api/pricing
 * {
 *   "action": "whale-analysis",
 *   "clientType": "regional_hospital"
 * }
 * 
 * Create checkout for Guardian Pilot:
 * POST /api/stripe/checkout
 * {
 *   "action": "create",
 *   "tierId": "guardian-pilot",
 *   "successUrl": "https://yourapp.com/success",
 *   "cancelUrl": "https://yourapp.com/cancel"
 * }
 */
