/**
 * INVOICE SERVICE — NorthStar Medic
 * 
 * Handles invoice creation and commission calculation
 * Connects claims → recoveries → commissions → invoices
 */

import { PrismaClient } from '@prisma/client';
import { calculateCommission, getTier } from './pricing-config.js';

const prisma = new PrismaClient();

/**
 * Create an invoice for a successful claim recovery
 * 
 * @param {Object} claim - The claim object from database
 * @param {string} tierId - The pricing tier (guardian-pilot, growth-lattice, network-core)
 * @param {number} recoveredAmount - The amount recovered/appealed
 * @param {boolean} viaBiller - Whether this came through a biller partnership
 * @returns {Promise<Object>} Created invoice
 */
export async function createInvoice(claim, tierId, recoveredAmount, viaBiller = false) {
  // Validate tier exists
  const tier = getTier(tierId);
  if (!tier) {
    throw new Error(`Invalid pricing tier: ${tierId}`);
  }

  // Calculate commission breakdown
  const commission = calculateCommission(recoveredAmount, tierId, viaBiller);

  // Create invoice in database
  const invoice = await prisma.invoice.create({
    data: {
      claimId: claim.id,
      amountEarned: commission.platformCommission,
      billerCommission: commission.billerCommission,
      status: 'PENDING', // Will be marked PAID when Stripe webhook confirms
      createdAt: new Date()
    }
  });

  // Update claim with invoice reference
  await prisma.claim.update({
    where: { id: claim.id },
    data: {
      status: 'INVOICED',
      updatedAt: new Date()
    }
  });

  return {
    invoiceId: invoice.id,
    claimId: claim.id,
    recoveredAmount: commission.recoveredAmount,
    tier: commission.tier,
    platformCommission: commission.platformCommission,
    billerCommission: commission.billerCommission,
    totalCommission: commission.totalCommission,
    status: invoice.status,
    createdAt: invoice.createdAt
  };
}

/**
 * Batch create invoices for multiple claims
 * Used when processing a month of successful appeals
 */
export async function batchCreateInvoices(claims, tierId, viaBiller = false) {
  const invoices = [];
  
  for (const claim of claims) {
    try {
      const invoice = await createInvoice(claim, tierId, claim.recoveredAmount || claim.billedAmount, viaBiller);
      invoices.push(invoice);
    } catch (error) {
      console.error(`Failed to create invoice for claim ${claim.id}:`, error);
    }
  }

  return invoices;
}

/**
 * Get invoice with detailed commission breakdown
 */
export async function getInvoice(invoiceId) {
  const invoice = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    include: {
      claim: {
        include: {
          batch: true,
          payer: true
        }
      }
    }
  });

  if (!invoice) {
    return null;
  }

  // Determine tier from claim metadata
  // (In a real system, you'd store this on the claim or user record)
  const userClaimCount = await prisma.claim.count({
    where: { batch: { userId: invoice.claim.batch.userId } }
  });

  return {
    id: invoice.id,
    claimId: invoice.claimId,
    claimDetails: {
      patientId: invoice.claim.patientId,
      cptCode: invoice.claim.cptCode,
      billedAmount: invoice.claim.billedAmount,
      denialReason: invoice.claim.denialReason,
      status: invoice.claim.status
    },
    payer: invoice.claim.payer?.name || 'Unknown',
    amountEarned: invoice.amountEarned,
    billerCommission: invoice.billerCommission,
    totalCommission: invoice.amountEarned + invoice.billerCommission,
    status: invoice.status,
    stripeInvoiceId: invoice.stripeInvoiceId,
    createdAt: invoice.createdAt
  };
}

/**
 * Get all invoices for a user (their earned commissions)
 */
export async function getUserInvoices(userId, status = null) {
  const invoices = await prisma.invoice.findMany({
    where: {
      claim: {
        batch: {
          userId: userId
        }
      },
      ...(status && { status })
    },
    include: {
      claim: true
    },
    orderBy: {
      createdAt: 'desc'
    }
  });

  return invoices.map(inv => ({
    id: inv.id,
    claimId: inv.claimId,
    claimValue: inv.claim.billedAmount,
    earned: inv.amountEarned,
    billerCommission: inv.billerCommission,
    totalValue: inv.amountEarned + inv.billerCommission,
    status: inv.status,
    createdAt: inv.createdAt
  }));
}

/**
 * Calculate total earnings for a user
 * Can filter by date range and status
 */
export async function calculateUserEarnings(userId, fromDate = null, toDate = null, status = 'PAID') {
  const where = {
    claim: {
      batch: {
        userId: userId
      }
    },
    status
  };

  if (fromDate || toDate) {
    where.createdAt = {};
    if (fromDate) where.createdAt.gte = fromDate;
    if (toDate) where.createdAt.lte = toDate;
  }

  const invoices = await prisma.invoice.findMany({ where });

  const totals = invoices.reduce((acc, inv) => ({
    totalEarned: acc.totalEarned + inv.amountEarned,
    totalBillerCommissions: acc.totalBillerCommissions + inv.billerCommission,
    invoiceCount: acc.invoiceCount + 1
  }), {
    totalEarned: 0,
    totalBillerCommissions: 0,
    invoiceCount: 0
  });

  return {
    userId,
    period: {
      from: fromDate || 'all-time',
      to: toDate || 'all-time'
    },
    status,
    ...totals,
    netEarnings: totals.totalEarned
  };
}

/**
 * Mark invoice as paid (called when Stripe webhook confirms payment)
 */
export async function markInvoiceAsPaid(invoiceId, stripeInvoiceId = null) {
  const invoice = await prisma.invoice.update({
    where: { id: invoiceId },
    data: {
      status: 'PAID',
      stripeInvoiceId: stripeInvoiceId || invoice.stripeInvoiceId,
      updatedAt: new Date()
    }
  });

  return invoice;
}

/**
 * Get revenue breakdown by tier
 * Shows which tiers are generating the most revenue
 */
export async function getRevenueByTier() {
  // In a real system, you'd store the tier on the claim or user
  // This is a simplified version
  const invoices = await prisma.invoice.findMany({
    include: {
      claim: {
        include: {
          batch: true
        }
      }
    }
  });

  const byTier = {};
  
  invoices.forEach(inv => {
    // Estimate tier based on commission rate
    // Real system would store this explicitly
    let tier = 'unknown';
    if (inv.amountEarned > 0) {
      tier = 'mixed'; // Without explicit storage, we can't determine
    }
    
    if (!byTier[tier]) {
      byTier[tier] = {
        invoiceCount: 0,
        totalEarned: 0,
        totalBillerCommissions: 0
      };
    }
    
    byTier[tier].invoiceCount += 1;
    byTier[tier].totalEarned += inv.amountEarned;
    byTier[tier].totalBillerCommissions += inv.billerCommission;
  });

  return byTier;
}

/**
 * Dashboard stats: Total MRR, Invoices pending, etc.
 */
export async function getDashboardStats(userId) {
  const [totalEarned, pendingInvoices, paidInvoices] = await Promise.all([
    calculateUserEarnings(userId, null, null, 'PAID'),
    prisma.invoice.count({
      where: {
        claim: { batch: { userId } },
        status: 'PENDING'
      }
    }),
    prisma.invoice.count({
      where: {
        claim: { batch: { userId } },
        status: 'PAID'
      }
    })
  ]);

  const pendingAmount = await prisma.invoice.aggregate({
    where: {
      claim: { batch: { userId } },
      status: 'PENDING'
    },
    _sum: { amountEarned: true }
  });

  return {
    totalEarned: totalEarned.totalEarned,
    pendingInvoices,
    pendingAmount: pendingAmount._sum.amountEarned || 0,
    paidInvoices,
    nextPayout: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
  };
}

export default {
  createInvoice,
  batchCreateInvoices,
  getInvoice,
  getUserInvoices,
  calculateUserEarnings,
  markInvoiceAsPaid,
  getRevenueByTier,
  getDashboardStats
};
